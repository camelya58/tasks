package annotations;

public enum Position {
    JUNIOR,
    MIDDLE,
    SENIOR,
    OTHER
}
