package annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.Target;
import java.util.Arrays;

@Changelog({
        @Revision(
                revision = 4089,
                date = @Date(year = 2011, month = 5, day = 30, hour = 18, minute = 35, second = 18),
                comment = "Новый файл добавлен"),
        @Revision(
                revision = 6018,
                date = @Date(year = 2013, month = 1, day = 1, hour = 0, minute = 0, second = 1),
                authors = {@Author(value = "Сергей", position = Position.MIDDLE)},
                comment = "Фикс багов"),
        @Revision(
                revision = 10135,
                date = @Date(year = 2014, month = 12, day = 31, hour = 23, minute = 59, second = 59),
                authors = {@Author(value = "Диана", position = Position.JUNIOR),
                        @Author("Игорь"),
                        @Author(value = "Виктор", position = Position.SENIOR)})
})
public class AnnotationExample {

    public static void main(String[] args) {
        if (AnnotationExample.class.isAnnotationPresent(Changelog.class)) {
            System.out.println(AnnotationExample.class.getAnnotation(Changelog.class).toString());
        }

        Annotation[] array = Target.class.getAnnotations();
        System.out.println(Arrays.toString(array));
    }
}
